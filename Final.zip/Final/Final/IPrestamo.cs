﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final
{
    public interface IPrestamo
    {
         void Prestar(string ISBNp);
        void Devolver(string ISBNp);

    }
}
