﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final
{
    public class Biblioteca : IPrestamo
    {
        public List<Libro> Libroslst = new List<Libro>();

        public void AgregarLibro(Libro librop)
        {
            foreach (Libro item in Libroslst)
            {
                if (item.ISBN == librop.ISBN)
                {
                    throw new PrestamoLibroExeption("No se pueden agregar libros repetidos");
                }
            }
            Libroslst.Add(librop);
        }

        public List<Libro> MostrarLibrosDisponibles()
        {
            List<Libro> disponibles = new List<Libro>();
            foreach (Libro item in Libroslst)
            {
                if (item.EstaDisponible == true)
                {
                    disponibles.Add(item);
                }
            }
            return disponibles;
        }

        public void Devolver(string ISBNp)
        {
            Boolean encontre = false;
            foreach (Libro item in Libroslst)
            {
                if (item.ISBN == ISBNp)
                {
                    encontre = true; 
                    if (item.EstaDisponible == true)
                    {
                        throw new PrestamoLibroExeption($"el libro: {ISBNp} esta disponible");
                    }
                    item.EstaDisponible = true;
                }
            }
            if (!encontre) throw new PrestamoLibroExeption($"No se encontro el libro: {ISBNp}");
        }

        public void Prestar(string ISBNp)
        {
            Boolean encontre = false;
            foreach (Libro item in Libroslst)
            {
                if (item.ISBN == ISBNp)
                {
                    encontre = true;
                    if (item.EstaDisponible == false)
                    {
                        throw new PrestamoLibroExeption($"el libro: {ISBNp} no esta disponible");
                    }
                    item.EstaDisponible = false;
                }

            }

            if(!encontre) throw new PrestamoLibroExeption($"No se encontro el libro: {ISBNp}");



        }
    }
}
