﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final
{
    public class Libro
    {
        

        public string Titulo { get; }
        public string Auto { get; }
        public string ISBN { get; }
        public bool EstaDisponible{ get; set; }


        public Libro(string titulo, string auto, string iSBN, bool Disponiblep)
        {
            Titulo = titulo;
            Auto = auto;
            ISBN = iSBN;
            EstaDisponible = Disponiblep;
        }



    }
}
