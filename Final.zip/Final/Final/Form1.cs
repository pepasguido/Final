﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Biblioteca miBiblioteca = null;
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                miBiblioteca = new Biblioteca();
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = miBiblioteca.Libroslst;
            }
            catch (PrestamoLibroExeption ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if(TxtTitulo.Text==""|| f.Text==""|| d.Text == "")
                {
                    MessageBox.Show("Completa los campos");
                }
                Libro miLibro = new Libro(TxtTitulo.Text, txtAuto.Text, txtISBN.Text, true);
                miBiblioteca.AgregarLibro(miLibro);
               


            }catch(PrestamoLibroExeption ex)
            {
                MessageBox.Show(ex.Message);
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = miBiblioteca.Libroslst;
            txtAuto.Text = "";
            txtISBN.Text = "";
            TxtTitulo.Text = "";
            textBox1.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "")
                {
                    throw new Exception("complete los campos");
                }
                miBiblioteca.Prestar(textBox1.Text);
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = miBiblioteca.Libroslst;

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            txtAuto.Text = "";
            txtISBN.Text = "";
            TxtTitulo.Text = "";
            textBox1.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "")
                {
                    throw new Exception("complete los campos");
                }
                miBiblioteca.Devolver(textBox1.Text);
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = miBiblioteca.Libroslst;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            txtAuto.Text = "";
            txtISBN.Text = "";
            TxtTitulo.Text = "";
            textBox1.Text = "";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            miBiblioteca.MostrarLibrosDisponibles();
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = miBiblioteca.MostrarLibrosDisponibles();


        }

        private void button6_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = miBiblioteca.Libroslst;
        }
    }
}
